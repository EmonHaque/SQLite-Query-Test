﻿using Microsoft.Data.Sqlite;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace SQLite
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        int commentHit = 0;
        Run currentRun;
        string fileName, funKeyQuery;
        char[] charTokens = { ',', ';', '(', ')', '.' };

        List<Info> tables;
        List<FunKey> funKeys;
        ScaleTransform queryScale, resultScale;
        SolidColorBrush okBrush, ErrorBrush, keyWordBrush, functionBrush, tableColumnBrush, commentBrush, defaultBrush;
        public ICollectionView Tables { get; set; }
        public ICollectionView FunKeys { get; set; }
        
        public event PropertyChangedEventHandler PropertyChanged;

        public MainWindow() {
            InitializeComponent();
            initializeScaleTransforms();
            initializeBrushes();
            getKeysAndFuncs();
            DataContext = this;
        }

        void initializeScaleTransforms() {
            queryScale = new ScaleTransform();
            resultScale = new ScaleTransform();
            txtQuery.LayoutTransform = queryScale;
            result.LayoutTransform = resultScale;
        }

        void initializeBrushes() {
            okBrush = Brushes.Green;
            ErrorBrush = Brushes.Red;
            keyWordBrush = Brushes.CornflowerBlue;
            functionBrush = Brushes.Coral;
            tableColumnBrush = Brushes.Green;
            commentBrush = Brushes.DarkGreen;
            defaultBrush = Brushes.Black;
        }

        void getKeysAndFuncs() {
            funKeys = new List<FunKey>();
            var files = Directory.GetFiles("KeysAndFunc", "*.txt");
            foreach (var file in files) {
                var name = file.Split("\\")[1].Replace(".txt", "");
                if (name.StartsWith("fn")) name = name.Remove(0, 2);
                var lines = File.ReadAllLines(file);
                foreach (var line in lines) {
                    funKeys.Add(new FunKey() {
                        Name = line,
                        Tag = name
                    });
                }
            }
            FunKeys = new CollectionViewSource() { Source = funKeys }.View;
            funKeyQuery = "";
            FunKeys.Filter = filterFunKeys;
        }

        bool filterFunKeys(object o) {
            var funKey = (FunKey)o;
            return funKey.Name.ToLower().StartsWith(funKeyQuery);
        }

        void getTables() {
            tables = new List<Info>();
            var con = new SqliteConnection("data source = " + fileName);
            con.Open();
            var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM sqlite_master";
            SqliteDataReader reader = null;
            try {
                reader = cmd.ExecuteReader();
            }
            catch (Exception e) {
                Debug.WriteLine(e.Message);
                con.Close();
                return;
            }

            while (reader.Read()) {
                tables.Add(new Info() {
                    Type = reader.GetString(0),
                    Name = reader.GetString(1)
                });
            }
            reader.Close();
            //con.Close();
            var txt = "";
            int count = 0;
            foreach (var table in tables) {
                if (table.Type.Equals("table")) {
                    txt += $"PRAGMA table_info({table.Name});";
                    count++;
                    funKeys.Add(new FunKey() {
                        Name = table.Name,
                        Tag = "Table"
                    });
                }
            }
            cmd.CommandText = txt;
            reader = cmd.ExecuteReader();
            List<string> columnNames = new();
            for (int i = 0; i < count; i++) {
                while (reader.Read()) {
                    var str = reader.GetString(1);
                    if (columnNames.Contains(str)) continue;
                    columnNames.Add(str);
                    funKeys.Add(new FunKey() {
                        Name = str,
                        Tag = "Column"
                    });
                }
                reader.NextResult();
            }
            con.Close();
            Tables = new CollectionViewSource() { Source = tables }.View;
            Tables.GroupDescriptions.Add(new PropertyGroupDescription("Type"));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Tables)));
        }

        void attach(object sender, RoutedEventArgs e) {
            var dialog = new OpenFileDialog();
            if (!dialog.ShowDialog().Value) return;

            fileName = dialog.FileName;
            getTables();
        }

        void onKeyUpOnSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Tab) return;
            setToken();
            suggestion.IsOpen = false;
            Keyboard.Focus(txtQuery);
        }

        void onKeyDownOnQuery(object sender, KeyEventArgs e) {
            currentRun = txtQuery.CaretPosition.Parent as Run;
            if (e.Key == Key.Tab) {
                if (!suggestion.IsOpen) return;
                suggestionList.SelectedIndex = 0;
                e.Handled = true;
                txtQuery.CaretPosition.InsertTextInRun("\t ");
                setToken();
                suggestion.IsOpen = false;
            }
            if (e.Key == Key.Down) {
                if (!suggestion.IsOpen) return;
                suggestionList.SelectedIndex = 0;
                e.Handled = true;
                txtQuery.CaretPosition.InsertTextInRun("\t ");
                Keyboard.Focus((ListBoxItem)suggestionList.ItemContainerGenerator.ContainerFromItem(suggestionList.SelectedItem));
            }
            if(e.Key == Key.Space) {
                //var lastToken = txtQuery.CaretPosition.GetTextInRun(LogicalDirection.Backward).Trim();
                //txtQuery.CaretPosition.DeleteTextInRun(lastToken.Length);
                //setRun(lastToken, '\0');
            }
        }

        void onKeyUpOnQuery(object sender, KeyEventArgs e) {
            suggestion.IsOpen = false;
            if (e.Key == Key.F5) {
                getResult();
                return;
            }
            if (e.Key == Key.Space || e.Key == Key.Back || e.Key == Key.Enter || e.Key == Key.Up) {
                return;
            }

            if (e.Key == Key.OemMinus || e.Key == Key.Subtract) {
                commentHit++;
                if (commentHit == 2) {
                    setToken();
                    commentHit = 0;
                }
                return;
            }
            if (currentRun is null) return;
            var text = txtQuery.CaretPosition.GetTextInRun(LogicalDirection.Backward).Split(' ');
            string query = text[text.Length - 1].Trim().ToLower();
            if (query.Contains("(")) {
                int index = query.IndexOf("(") + 1;
                query = query.Substring(index, query.Length - index);

            }
            funKeyQuery = query;
            FunKeys.Refresh();
            suggestion.PlacementRectangle = txtQuery.CaretPosition.GetCharacterRect(LogicalDirection.Forward);
            if (suggestionList.Items.Count > 0) suggestion.IsOpen = true;

            e.Handled = true;
        }

        void setToken() {
            suggestion.IsOpen = false;
            var key = (FunKey)FunKeys.CurrentItem;
            if (key is null) return;

            var para = txtQuery.CaretPosition.Paragraph;
            var tokens = new TextRange(para.ContentStart, para.ContentEnd).Text.Split(" ");
            para.Inlines.Clear();

            foreach (var token in tokens) {
                if (token.Equals("")) continue;

                string text = "";
                for (int i = 0; i < token.Length; i++) {
                    if (charTokens.Contains(token[i])) {
                        if (text != "") {
                            setRun(text, token[i]);
                            text = "";
                        }
                        var str = token[i].ToString();
                        var run = new Run(str);
                        if (token[i].Equals(')')) run.Text += " ";
                        setNormalStyle(run, getTag(str));
                        para.Inlines.Add(run);
                    }
                    else text += token[i];
                    if (i == token.Length - 1 && !text.Equals("")) {
                        setRun(text, token[i]);
                    }
                }
            }
            txtQuery.CaretPosition = para.Inlines.First(x => x.Tag != null && x.Tag.Equals(1)).ElementEnd;
        }

        string getTag(string token) {
            if (token.EndsWith('\t')) return ((FunKey)FunKeys.CurrentItem).Tag;
            if (token.Equals("(") || token.Equals(")")) return "Core Function";
            else {
                var tag = funKeys.FirstOrDefault(x => x.Name.ToLower().Equals(token.ToLower()));
                if (tag is null) {
                    tag = funKeys.FirstOrDefault(x => x.Name.ToLower().StartsWith(token.ToLower()));
                }
                return tag == null ? null : tag.Tag;
            }
        }

        void setRun(string token, char nextToken) {
            var para = txtQuery.CaretPosition.Paragraph;
            var run = new Run(token);
            if (token.EndsWith('\t')) {
                run.Text = ((FunKey)FunKeys.CurrentItem).Name;
                run.Tag = 1;
            }
            else {
                if (!(nextToken.Equals('(') || nextToken.Equals(')')))
                    run.Text += " ";
            }
            setNormalStyle(run, getTag(token));
            para.Inlines.Add(run);
        }

        void setCommentStyle(Run run) {
            run.Foreground = commentBrush;
        }

        void setNormalStyle(Run run, object tag) {
            switch (tag) {
                case "Core Function":
                case "Aggregate Function":
                case "Math Function":
                    run.Foreground = functionBrush;
                    run.FontWeight = FontWeights.Bold;
                    break;
                case "Table":
                case "Column":
                    run.Foreground = tableColumnBrush;
                    break;
                case "Keyword":
                    run.Foreground = keyWordBrush;
                    run.FontWeight = FontWeights.Bold;
                    break;
                default: run.Foreground = defaultBrush; break;
            }
        }

        void getResult() {
            if (string.IsNullOrEmpty(fileName)) {
                txtInfo.Foreground = ErrorBrush;
                txtInfo.Text = "No database attached!";
                return;
            }
            var query = new TextRange(txtQuery.Document.ContentStart, txtQuery.Document.ContentEnd).Text;
            var started = DateTime.Now;
            var table = new DataTable();

            var con = new SqliteConnection("data source = " + fileName);
            con.Open();
            var cmd = con.CreateCommand();
            cmd.CommandText = query;
            try { table.Load(cmd.ExecuteReader(CommandBehavior.CloseConnection)); }
            catch (Exception e) {
                txtInfo.Foreground = ErrorBrush;
                txtInfo.Text = e.Message;
                return;
            }
            result.ItemsSource = table.DefaultView;

            var finished = DateTime.Now;
            var elapsed = finished - started;
            txtInfo.Foreground = okBrush;
            txtInfo.Text = $"Execution finished in {elapsed.TotalMilliseconds.ToString("N0")} ms\r\nReturned {table.Rows.Count} rows";
        }

        void zoomQuery(object sender, MouseWheelEventArgs e) {
            if (Keyboard.Modifiers != ModifierKeys.Control) return;
            if (e.Delta < 0) {
                if (queryScale.ScaleX <= 1) return;
                queryScale.ScaleX /= 1.1;
                queryScale.ScaleY /= 1.1;
            }
            else {
                queryScale.ScaleX *= 1.1;
                queryScale.ScaleY *= 1.1;
            }
        }

        void zoomResult(object sender, MouseWheelEventArgs e) {
            if (Keyboard.Modifiers != ModifierKeys.Control) return;
            if (e.Delta < 0) {
                if (resultScale.ScaleX <= 1) return;
                resultScale.ScaleX /= 1.1;
                resultScale.ScaleY /= 1.1;
            }
            else {
                resultScale.ScaleX *= 1.1;
                resultScale.ScaleY *= 1.1;
            }
        }
    }
}
