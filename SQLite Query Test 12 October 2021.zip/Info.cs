﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLite
{
    public class Info
    {
        public string Type { get; set; }
        public string Name { get; set; }
    }
}
