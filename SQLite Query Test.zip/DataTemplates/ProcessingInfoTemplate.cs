﻿using SQLite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace SQLite.DataTemplates
{
    class ProcessingInfoTemplate: DataTemplate
    {
        public ProcessingInfoTemplate() {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var timeBlock = new FrameworkElementFactory(typeof(TextBlock));
            var infoBlock = new FrameworkElementFactory(typeof(TextBlock));

            col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, GridUnitType.Auto));
            infoBlock.SetValue(Grid.ColumnProperty, 1);
            infoBlock.SetValue(TextBlock.MarginProperty, new Thickness(10, 0, 0, 5));
            timeBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(ProcessingInfo.Time)));
            infoBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(ProcessingInfo.Message)));

            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(timeBlock);
            grid.AppendChild(infoBlock);

            VisualTree = grid;

            Triggers.Add(new DataTrigger() {
                Binding = new Binding(nameof(ProcessingInfo.IsError)),
                Value = true,
                Setters = { new Setter(TextElement.ForegroundProperty, Brushes.Red) }
            });
        }
    }
}
