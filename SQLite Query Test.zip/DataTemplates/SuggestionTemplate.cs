﻿using SQLite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SQLite.DataTemplates
{
    class SuggestionTemplate : DataTemplate
    {
        public SuggestionTemplate() {
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));

            col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(16));
            var icon = new FrameworkElementFactory(typeof(Path));
            var token = new FrameworkElementFactory(typeof(TextBlock));
            var tag = new FrameworkElementFactory(typeof(TextBlock));

            icon.SetValue(Path.StretchProperty, Stretch.Uniform);
            icon.SetValue(Path.WidthProperty, 16d);
            icon.SetValue(Path.HeightProperty, 16d);
            icon.SetValue(Path.FillProperty, Brushes.Gray);

            token.SetValue(TextBlock.MarginProperty, new Thickness(10, 0, 10, 0));
            token.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            token.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);

            tag.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            tag.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
            tag.SetValue(TextBlock.FontStyleProperty, FontStyles.Italic);
            tag.SetValue(TextBlock.ForegroundProperty, Brushes.Gray);

            token.SetValue(Grid.ColumnProperty, 1);
            tag.SetValue(Grid.ColumnProperty, 2);

            icon.SetBinding(Path.DataProperty, new Binding(nameof(FunKey.Icon)));
            token.SetBinding(TextBlock.TextProperty, new Binding(nameof(FunKey.Name)));
            tag.SetBinding(TextBlock.TextProperty, new Binding(nameof(FunKey.Tag)));


            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(col3);
            grid.AppendChild(icon);
            grid.AppendChild(token);
            grid.AppendChild(tag);

            VisualTree = grid;
        }
    }
}
