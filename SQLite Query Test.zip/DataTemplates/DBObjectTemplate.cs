﻿using SQLite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace SQLite.DataTemplates
{
    class DBObjectTemplate : DataTemplate
    {
        public DBObjectTemplate() {
            var objectName = new FrameworkElementFactory(typeof(TextBlock));
            objectName.SetBinding(TextBlock.TextProperty, new Binding(nameof(DBObjectInfo.Name)));
            VisualTree = objectName;
        }
    }
}
