﻿using SQLite.CustomControls;
using System.Windows;
using System.Windows.Input;

namespace SQLite.Abstracts
{
    abstract class CardView : View
    {
        public abstract string Header { get; }
        public override FrameworkElement container => card;
        Card card;
        public CardView() {
            card = new Card() { Header = Header };
            AddVisualChild(card);
            KeyboardNavigation.SetTabNavigation(this, KeyboardNavigationMode.Cycle);
            FocusManager.SetIsFocusScope(this, true);
        }
        protected void setContent(FrameworkElement element) => card.Content = element;
        protected void setActionIcons(FrameworkElement element) => card.ActionIcons = element;
        protected void resetMargin(Thickness margin) => card.Margin = margin;
    }
}
