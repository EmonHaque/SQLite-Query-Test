﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SQLite.CustomControls
{
    class LoadingWindow : Window
    {
        Path arc;
        PointAnimationUsingPath pointAnim;
        BooleanAnimationUsingKeyFrames isLargeAnim;

        public LoadingWindow() {
            Height = Width = 300;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            AllowsTransparency = true;
            ShowInTaskbar = false;
            Background = Brushes.Transparent;
            initializeContent();
            initializeAnimations();
            Loaded += animateArc;
            Unloaded += onUnloaded;
        }
        void onUnloaded(object sender, RoutedEventArgs e) {
            Loaded -= animateArc;
            Unloaded -= onUnloaded;
        }
        void initializeAnimations() {
            pointAnim = new PointAnimationUsingPath() {
                PathGeometry = PathGeometry.CreateFromGeometry(arc.Data),
                Duration = TimeSpan.FromSeconds(2),
                AccelerationRatio = 0.5,
                DecelerationRatio = 0.5,
                RepeatBehavior = RepeatBehavior.Forever
            };
            isLargeAnim = new BooleanAnimationUsingKeyFrames() {
                KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(1)),
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(2))
                },
                RepeatBehavior = RepeatBehavior.Forever
            };
        }
        void animateArc(object sender, RoutedEventArgs e) {
            var segment = (ArcSegment)((PathGeometry)arc.Data).Figures[0].Segments[0];
            segment.BeginAnimation(ArcSegment.PointProperty, pointAnim);
            segment.BeginAnimation(ArcSegment.IsLargeArcProperty, isLargeAnim);
        }
        void initializeContent() {
            var ellipse = new Path() {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Fill = Brushes.White,
                Data = new EllipseGeometry() {
                    Center = new Point(150, 150),
                    RadiusX = 150,
                    RadiusY = 150
                }
            };
            arc = new Path() {
                Stroke = Brushes.Coral,
                StrokeThickness = 5,
                Data = new PathGeometry() {
                    Figures = {
                        new PathFigure() {
                            StartPoint = new Point(298, 150),
                            Segments = {
                                new ArcSegment() {
                                    IsLargeArc = true,
                                    Point = new Point(298, 149.9),
                                    Size = new Size(148,148),
                                    SweepDirection = SweepDirection.Clockwise
                                }
                            }
                        }
                    }
                }
            };
            var image = new Image() {
                Margin = new Thickness(0, 30, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Top,
                Width = 96,
                Height = 96,
            };
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("SQLite.Resources.LoadingIcon.png")) {
                image.Source = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            }
            var text = new TextBlock() {
                Margin = new Thickness(0, 0, 0, 60),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Bottom,
                TextAlignment = TextAlignment.Center,
                FontSize = 36,
                Foreground = Brushes.Coral,
                Inlines = {
                    new Run(){Text = "Query Lite", Foreground = Brushes.SkyBlue, FontWeight = FontWeights.Bold },
                    new LineBreak(),
                    new Run(){Text = "loading...", Foreground = Brushes.Coral}
                }
            };
            Content = new Grid() { Children = { ellipse, text, arc, image } };
        }
    }
}
