﻿using SQLite.Helpers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace SQLite.CustomControls
{
    class Card : Border
    {
        Grid container;
        TextBlock headerBlock;
        Separator divider;
        UIElement content;
        public UIElement Content {
            get { return content; }
            set {
                content = value;
                Grid.SetRow(value, 2);
                Grid.SetColumnSpan(value, 2);
                container.Children.Add(value);
            }
        }
        UIElement actionIcons;
        public UIElement ActionIcons {
            get { return actionIcons; }
            set { 
                actionIcons = value;
                Grid.SetColumn(value, 1);
                container.Children.Add(value);
            }
        }

        string header;
        public string Header {
            get { return header; }
            set {
                header = value;
                headerBlock.Text = value;
                headerBlock.Visibility = Visibility.Visible;
                divider.Visibility = Visibility.Visible;
            }
        }

        public Card() {
            headerBlock = new TextBlock() {
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                VerticalAlignment = VerticalAlignment.Center,
                Visibility = Visibility.Collapsed
            };
            divider = new Separator() {
                Margin = new Thickness(0, 0, 0, 5),
                Background = Brushes.LightGray,
                Visibility = Visibility.Collapsed
            };
            Grid.SetRow(divider, 1);
            Grid.SetColumnSpan(divider, 2);
            container = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Auto)},
                    new ColumnDefinition()
                },
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
                Children = { headerBlock, divider }
            };
            Margin = Constants.CardMargin;
            Padding = new Thickness(5);
            CornerRadius = new CornerRadius(5);
            Background = Brushes.White;
            Effect = new DropShadowEffect() { BlurRadius = 10, ShadowDepth = 0 };
            Child = container;
        }

        protected override Size MeasureOverride(Size constraint) {
            var width = constraint.Width - Padding.Left - Padding.Right;
            var height = constraint.Height - Padding.Top - Padding.Bottom;
            container.Width = width > 0 ? width : 0;
            container.Height = height > 0 ? height : 0;
            return constraint;
        }
    }
}
