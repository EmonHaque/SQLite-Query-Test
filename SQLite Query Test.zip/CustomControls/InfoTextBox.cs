﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace SQLite.CustomControls
{
    class InfoTextBox : TextBox
    {
        public InfoTextBox() {
            BorderThickness = new Thickness(0);
            IsReadOnly = true;
        }
        protected override void OnMouseWheel(MouseWheelEventArgs e) {
            if (Keyboard.Modifiers != ModifierKeys.Control) return;
            if (e.Delta < 0 && FontSize > 12) FontSize -= 1;
            else FontSize += 1;
        }
    }
}
