﻿using SQLite.ControlTemplates;
using SQLite.ViewModels;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace SQLite.CustomControls
{
    class ResultGrid : DataGrid
    {
        List<TextBox> queryBoxes;
        bool isRefreshing;
        string[] queries;

        public ResultGrid() {
            queryBoxes = new List<TextBox>();
            EnableRowVirtualization = true;
            EnableColumnVirtualization = true;
            SetValue(VirtualizingPanel.VirtualizationModeProperty, VirtualizationMode.Recycling);
            SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
            
            CanUserAddRows = false;
            CanUserDeleteRows = false;
            CanUserSortColumns = false;
            CanUserReorderColumns = false;
            AutoGenerateColumns = false;
            
            HorizontalGridLinesBrush = Brushes.LightGray;
            VerticalGridLinesBrush = Brushes.LightGray;
            BorderThickness = new Thickness(0);
            HeadersVisibility = DataGridHeadersVisibility.Column;
            IsReadOnly = true;
            Background = null;
            
            Style = new Style(typeof(ResultGrid)) {
                Setters = { new Setter(){Property = VisibilityProperty, Value = Visibility.Visible } },
                Triggers = {
                    new DataTrigger() {
                        Binding = new Binding(nameof(ItemsSource)){ RelativeSource = new RelativeSource(RelativeSourceMode.Self)},
                        Value = null,
                        Setters = {new Setter(VisibilityProperty, Visibility.Hidden)}
                    }
                }
            };

            ColumnHeaderStyle = new Style(typeof(DataGridColumnHeader)) {
                Setters = { new Setter(DataGridColumnHeader.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch) }
            };
            TableVM.IsRefreshing += onIsRefreshing;
        }

        void onIsRefreshing() {
            isRefreshing = true;
            if(Query is not null) {
                queries = Query.Split(" AND ");
            }
        }

        protected override void OnItemsSourceChanged(IEnumerable oldValue, IEnumerable newValue) {           
            if(oldValue != null) {
                Query = string.Empty;
                foreach (var box in queryBoxes) {
                    box.KeyUp -= onTextChanged;
                }
                queryBoxes.Clear();
                Columns.Clear();
            }
            if (newValue is null) return;
            var table = ((DataView)newValue).Table;
            if (table is null) return;
            foreach (DataColumn dataColumn in table.Columns) {
                var block = new TextBlock() { 
                    Text = dataColumn.ColumnName, 
                    FontWeight = FontWeights.Bold
                };
                var box = new TextBox() { 
                    Tag = dataColumn.ColumnName,
                    MinHeight = 30,
                    VerticalContentAlignment = VerticalAlignment.Center
                };
                box.SetValue(Grid.RowProperty, 1);
                box.KeyUp += onTextChanged;
                queryBoxes.Add(box);
                var grid = new Grid() { 
                    RowDefinitions = {
                        new RowDefinition(),
                        new RowDefinition()
                    },
                    Children = { block, box } 
                };
                var cell = new FrameworkElementFactory(typeof(TextBlock));
                cell.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
                cell.SetBinding(TextBlock.TextProperty, new Binding(dataColumn.ColumnName) { Mode = BindingMode.OneTime });
                var column = new DataGridTemplateColumn() { 
                    Header = grid,
                    CellTemplate = new DataTemplate() { VisualTree = cell },
                    MinWidth = 50,
                    MaxWidth = 700
                };
                Columns.Add(column);
            }
            if (isRefreshing && queries is not null) {
                List<string> q = new();
                foreach (var box in queryBoxes) {
                    foreach (var query in queries) {
                        var tag = box.Tag.ToString();
                        if (query.StartsWith(tag)) {
                            box.Text = query.Replace(tag, "").Trim();
                            q.Add(query);
                            break;
                        }
                    }
                }
                Query = string.Join(" AND ", q);
                isRefreshing = false;
                queries = null;
            }
        }

        void onTextChanged(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            string query = "";
            foreach (var box in queryBoxes) {
                if (!string.IsNullOrWhiteSpace(box.Text)) {
                    query += box.Tag + " " + box.Text + " AND ";
                }
            }
            Query = 
                query.EndsWith(" AND ") ? 
                query.Substring(0, query.LastIndexOf("AND")).Trim() :
                string.Empty;        
        }

        protected override void OnPreviewMouseWheel(MouseWheelEventArgs e) {
            if (Keyboard.Modifiers != ModifierKeys.Control) return;
            var size = (double)GetValue(TextElement.FontSizeProperty);
            if (e.Delta < 0) {
                if (size <= 12) return;
                SetValue(TextElement.FontSizeProperty, --size);
            }
            else SetValue(TextElement.FontSizeProperty, ++size);
        }

        public string Query {
            get { return (string)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(string), typeof(ResultGrid), new PropertyMetadata(null));
    }
}
