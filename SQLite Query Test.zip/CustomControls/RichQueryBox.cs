﻿using SQLite.DataTemplates;
using SQLite.Helpers;
using SQLite.Models;
using SQLite.ViewModels.TSQL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace SQLite.CustomControls
{
    class RichQueryBox :RichTextBox
    {
        char[] charTokens = { ',', ';', '(', ')', '[', ']', '.' };
        string query = "";
        string deleted = "";
        bool isHandled, unCommented;
        TextRange currentRange;
        Popup suggestion;
        ListBox suggestionList;
        ICollectionView FunKeys;
        SolidColorBrush keyWordBrush, functionBrush, tableColumnBrush, commentBrush, defaultBrush;
        public FunKey SelectedFunKey { get; set; }
        public Action<string> Execute { get; set; }
        public new ICommand Paste { get; set; }
        public ICommand Comment { get; set; }
        public ICommand ExecuteSelected { get; set; }
        public string Statements { get => new TextRange(Document.ContentStart, Document.ContentEnd).Text; }

        public RichQueryBox() {
            AcceptsTab = true;
            AcceptsReturn = true;
            AllowDrop = true;
            BorderThickness = new Thickness(0);

            ScrollViewer.SetVerticalScrollBarVisibility(this, ScrollBarVisibility.Auto);
            Resources.Add(typeof(Paragraph), new Style(typeof(Paragraph)) {
                Setters = { new Setter(Paragraph.MarginProperty, new Thickness(0)) }
            });
            initializeBrushes();
            initializeCommands();
            initializeContextMenu();
            FunKeys = new CollectionViewSource() { Source = AppData.funKeys }.View;
            FunKeys.Filter = filter;
            suggestionList = new ListBox() {
                BorderThickness = new Thickness(1),
                ItemsSource = FunKeys,
                ItemTemplate = new SuggestionTemplate()
            };
            suggestionList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(SelectedFunKey)) {
                Source = this,
                Mode = BindingMode.OneWayToSource
            });
            suggestion = new Popup() {
                VerticalOffset = 5,
                HorizontalOffset = 10,
                MaxHeight = 300,
                PlacementTarget = this,
                Child = suggestionList
            };
            suggestionList.KeyUp += onKeyUpOnSuggestion;
            Unloaded += onUnLoaded;

        }

        void initializeContextMenu() {
            var executeSekectedKey = new KeyBinding() {
                Command = ExecuteSelected,
                Key = Key.E,
                Modifiers = ModifierKeys.Control
            };
            var commentKey = new KeyBinding() {
                Command = Comment,
                Key = Key.K,
                Modifiers = ModifierKeys.Control
            };
            BindingOperations.SetBinding(executeSekectedKey, InputBinding.CommandParameterProperty, new Binding(nameof(ExecuteSelected)));
            BindingOperations.SetBinding(commentKey, InputBinding.CommandParameterProperty, new Binding(nameof(Comment)));
            InputBindings.Add(executeSekectedKey);
            InputBindings.Add(commentKey);
            var comment = new MenuItem() { Header = "Comment/Uncomment", Command = Comment, InputGestureText = "Ctrl+K" };
            var executeSelected = new MenuItem() { Header = "Execute Selection", Command = ExecuteSelected, InputGestureText = "Ctrl+E" };
            var cut = new MenuItem() { Header = "Cut", Command = ApplicationCommands.Cut };
            var copy = new MenuItem() { Header = "Copy", Command = ApplicationCommands.Copy };
            var paste = new MenuItem() { Header = "Paste", Command = Paste, InputGestureText = "Ctrl+V" };
            ContextMenu = new ContextMenu() {
                Items = { comment, executeSelected, cut, copy, paste }
            };
        }

        void initializeCommands() {
            Paste = new Command(contextMenuPaste, canContextMenuPaste);
            Comment = new Command(contextMenuComment, canContextMenuComment);
            ExecuteSelected = new Command(contextMenuExecute, canContextMenuExecute);
        }

        #region ICommands
        void contextMenuComment(object obj) {
            if (Selection.Start.IsAtLineStartPosition) blockComment();
        }
        bool canContextMenuComment(object arg) => !Selection.IsEmpty;
        void contextMenuPaste(object obj) => formatOnPaste(Clipboard.GetText());
        bool canContextMenuPaste(object arg) => Clipboard.ContainsText();
        void contextMenuExecute(object obj) => Execute.Invoke(Selection.Text);
        bool canContextMenuExecute(object arg) => !Selection.IsEmpty;
        #endregion

        void onUnLoaded(object sender, RoutedEventArgs e) {
            suggestionList.KeyUp -= onKeyUpOnSuggestion;
        }

        void initializeBrushes() {
            keyWordBrush = Brushes.CornflowerBlue;
            functionBrush = Brushes.Coral;
            tableColumnBrush = Brushes.DarkGreen;
            commentBrush = Brushes.LightGray;
            defaultBrush = Brushes.Black;
        }

        bool filter(object o) => ((FunKey)o).Name.ToLower().StartsWith(query);

        void onKeyUpOnSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Tab) return;
            suggestion.IsOpen = false;
            Keyboard.Focus(this);
            EditingCommands.DeletePreviousWord.Execute(null, this);
            currentRange = new TextRange(CaretPosition, CaretPosition);
            currentRange.Text = SelectedFunKey.Name;
            formatOnTab();
        }

        protected override void OnPreviewKeyUp(KeyEventArgs e) {
            if (unCommented) {
                var pos = CaretPosition;
                var range = new TextRange(CaretPosition, CaretPosition.Paragraph.ContentEnd);
                var tokens = range.Text;
                range.Text = "";
                formatOnPaste(tokens);
                CaretPosition = pos;
                return;
            }
            if (isHandled) {
                isHandled = false;
                return;
            }
            suggestion.IsOpen = false;
            if (e.Key == Key.Up || e.Key == Key.Left || e.Key == Key.Right || e.Key == Key.Down ||
                e.Key == Key.Back || e.Key == Key.Tab || e.Key == Key.CapsLock || e.Key == Key.Escape ||
                Keyboard.Modifiers == ModifierKeys.Shift ||
                Keyboard.Modifiers == ModifierKeys.Control ||
                Keyboard.Modifiers == ModifierKeys.Alt) {
                return;
            }
            else if (e.Key == Key.Space) {
                currentRange = new TextRange(CaretPosition.GetPositionAtOffset(-1), CaretPosition);
                currentRange.ApplyPropertyValue(TextElement.ForegroundProperty, defaultBrush);
                currentRange.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
                return;
            }
            else if (e.Key == Key.Enter) {
                currentRange = new TextRange(CaretPosition.Paragraph.ContentStart, CaretPosition.GetPositionAtOffset(1));
                currentRange.ApplyPropertyValue(TextElement.ForegroundProperty, defaultBrush);
                currentRange.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
                return;
            }
            else if (e.Key == Key.OemMinus || e.Key == Key.Subtract) {
                var range = new TextRange(CaretPosition.GetPositionAtOffset(-2), CaretPosition.Paragraph.ContentEnd);
                if (range.Text.StartsWith("--")) {
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, commentBrush);
                    range.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
                }
                return;
            }

            var text1 = CaretPosition.GetTextInRun(LogicalDirection.Backward);
            if (text1.EndsWith(' ')) return;
            var text = text1.Split(' ');
            string queryTrimmed = text[text.Length - 1].Trim().ToLower();
            if (queryTrimmed.Contains("(")) {
                int index = queryTrimmed.IndexOf("(") + 1;
                queryTrimmed = queryTrimmed.Substring(index, queryTrimmed.Length - index);
            }
            else if (queryTrimmed.Contains(".")) {
                int index = queryTrimmed.IndexOf(".") + 1;
                queryTrimmed = queryTrimmed.Substring(index, queryTrimmed.Length - index);
            }
            query = queryTrimmed;
            FunKeys.Refresh();
            suggestion.PlacementRectangle = CaretPosition.GetCharacterRect(LogicalDirection.Forward);
            if (suggestionList.Items.Count > 0) suggestion.IsOpen = true;

            e.Handled = true;
        }
        protected override void OnPreviewKeyDown(KeyEventArgs e) {
            if (e.Key == Key.Tab) {
                if (!suggestion.IsOpen) return;
                suggestionList.SelectedIndex = 0;
                e.Handled = true;
                isHandled = true;
                EditingCommands.DeletePreviousWord.Execute(null, this);
                currentRange = new TextRange(CaretPosition, CaretPosition);
                currentRange.Text = SelectedFunKey.Name;
                formatOnTab();
                suggestion.IsOpen = false;
            }
            else if (e.Key == Key.Down) {
                if (!suggestion.IsOpen) return;
                suggestionList.SelectedIndex = 0;
                e.Handled = true;
                isHandled = true;
                Keyboard.Focus((ListBoxItem)suggestionList.ItemContainerGenerator.ContainerFromItem(suggestionList.SelectedItem));
            }
            else if (e.Key == Key.F5) {
                e.Handled = true;
                isHandled = true;
                Execute.Invoke(new TextRange(Document.ContentStart, Document.ContentEnd).Text);
            }
            else if ((Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.V) ||
                (Keyboard.Modifiers == ModifierKeys.Shift && e.Key == Key.Insert)) {
                e.Handled = true;
                isHandled = true;
                if (Clipboard.ContainsText())
                    formatOnPaste(Clipboard.GetText());
            }
            else if(e.Key == Key.Back) {
                var character = new TextRange(CaretPosition.GetPositionAtOffset(-1), CaretPosition).Text;
                deleted += character;
                if (deleted.Equals("--")) 
                    unCommented = true;
            }
            else {
                unCommented = false;
                deleted = "";
            }
        }
        protected override void OnDragOver(DragEventArgs e) {
            base.OnDragOver(e);
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 1) {
                    e.Effects = DragDropEffects.None;
                    return;
                }
                var extension = Path.GetExtension(files[0]).ToUpperInvariant();
                if (!(extension == ".TXT" || extension == ".SQL")) {
                    e.Effects = DragDropEffects.None;
                    return;
                }
                e.Effects = DragDropEffects.Copy;
            }
            else e.Effects = DragDropEffects.None;
        }
        protected override void OnDrop(DragEventArgs e) {
            base.OnDrop(e);
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
            var filePath = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
            formatOnPaste(File.ReadAllText(filePath));
        }
        protected override void OnMouseWheel(MouseWheelEventArgs e) {
            base.OnMouseWheel(e);
            if (Keyboard.Modifiers == ModifierKeys.Control) {
                if (e.Delta < 0 && Document.FontSize > 12) Document.FontSize -= 1;
                else Document.FontSize += 1;
                isHandled = true;
            }
        }

        void formatOnTab() {
            switch (SelectedFunKey.Tag) {
                case "Scalar Function":
                case "Aggregate Function":
                case "Math Function":
                case "Window Function":
                case "Date And Time Function":
                case "JSON Function":
                    currentRange.ApplyPropertyValue(TextElement.ForegroundProperty, functionBrush);
                    currentRange.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
                    break;
                case "Table":
                case "Column":
                    currentRange.ApplyPropertyValue(TextElement.ForegroundProperty, tableColumnBrush);
                    break;
                case "Keyword":
                    currentRange.ApplyPropertyValue(TextElement.ForegroundProperty, keyWordBrush);
                    currentRange.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
                    break;
                default:
                    currentRange.ApplyPropertyValue(TextElement.ForegroundProperty, defaultBrush);
                    break;
            }
        }

        void formatOnPaste(string pastedText) {
            if (!Selection.IsEmpty) {
                Selection.Text = "";
            }
            var lines = pastedText.Split(Environment.NewLine);
            bool isComment;
            string text;
            int count = 0;
            foreach (var line in lines) {
                isComment = false;
                if (!string.IsNullOrWhiteSpace(line)) {
                    var tokens = line.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                    if (tokens[0].StartsWith("--")) isComment = true;

                    foreach (var token in tokens) {
                        text = "";
                        for (int i = 0; i < token.Length; i++) {
                            if (charTokens.Contains(token[i])) {
                                if (text != "") {
                                    addToken(text, token[i], isComment);
                                    text = "";
                                }
                                addToken(token[i].ToString(), '\0', isComment);
                            }
                            else text += token[i];
                            if (i == token.Length - 1 && !text.Equals("")) {
                                addToken(text, token[i], isComment);
                            }
                        }
                    }
                }
                count++;
                if (count < lines.Length) {
                    CaretPosition = CaretPosition.InsertParagraphBreak();
                }
            }
            isHandled = true;
        }

        string getTag(string token) {
            if (token.Equals("(") || token.Equals(")")) return "Core Function";
            else {
                string cleanToken = token.Replace("\t", "").ToLower();
                var tag = AppData.funKeys.FirstOrDefault(x => x.Name.ToLower().Equals(cleanToken));
                if (tag is null) {
                    tag = AppData.funKeys.FirstOrDefault(x => x.Name.ToLower().StartsWith(cleanToken));
                }
                return tag == null ? null : tag.Tag;
            }
        }

        void addToken(string token, char nextToken, bool isComment) {
            var range = new TextRange(CaretPosition, CaretPosition);
            range.Text = token;
            if (!(nextToken.Equals('(') || nextToken.Equals('[') || nextToken.Equals('.') || nextToken.Equals(',')))
                range.Text += " ";

            if (isComment) setCommentStyle(range);
            else setNormalStyle(range, getTag(token));
            CaretPosition = range.End;
        }

        void setCommentStyle(TextRange range) {
            range.ApplyPropertyValue(TextElement.ForegroundProperty, commentBrush);
        }

        void blockComment() {
            if (Selection.Text.StartsWith("--")) {
                var start = Selection.Start;
                var text = Selection.Text.Replace("--", "");
                formatOnPaste(text);
                Selection.Select(start, CaretPosition);
            }
            else {
                Selection.Text = Selection.Text.Insert(0, "--").Replace("\r\n", "\r\n--");
                Selection.ApplyPropertyValue(TextElement.ForegroundProperty, commentBrush);
            }
        }

        void setNormalStyle(TextRange range, object tag) {
            switch (tag) {
                case "Scalar Function":
                case "Aggregate Function":
                case "Math Function":
                case "Window Function":
                case "Date And Time Function":
                case "JSON Function":
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, functionBrush);
                    range.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
                    break;
                case "Table":
                case "Column":
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, tableColumnBrush);
                    range.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
                    break;
                case "Keyword":
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, keyWordBrush);
                    range.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
                    break;
                default:
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, defaultBrush);
                    range.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
                    break;
            }
        }
    }
}
