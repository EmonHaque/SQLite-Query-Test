﻿using SQLite.CustomControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using SQLite.Views;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using SQLite.Helpers;

namespace SQLite
{
    class App : Application
    {
        [STAThread]
        static void Main() => new App().Run();

        protected override void OnStartup(StartupEventArgs e) {
            LoadingWindow loading = null;
            var thread = new Thread(() => {
                loading = new LoadingWindow();
                loading.Show();
                Dispatcher.Run();
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            Thread.Sleep(2000);

            setResourceAndStyles();
            new AppData();

            Current.MainWindow = new RootWindow() {
                Content = new RootPanel() {
                    Children = {
                        new TSQLView(),
                        new TableView()
                    }
                }
            };
            Current.MainWindow.Show();
            Current.MainWindow.Activate();

            loading.Dispatcher.Invoke(loading.Close);
            loading.Dispatcher.InvokeShutdown();
        }

        void setResourceAndStyles() {
            Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
            Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);
            Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
                DefaultValue = new Style() {
                    Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                    Triggers = {
                        new Trigger() {
                            Property = ScrollBar.OrientationProperty,
                            Value = Orientation.Horizontal,
                            Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                        }
                    }
                }
            });
            Control.StyleProperty.OverrideMetadata(typeof(ListBox), new FrameworkPropertyMetadata() {
                DefaultValue = new Style() {
                    Setters = {
                        new Setter(ListBox.BorderThicknessProperty, new Thickness(0)),
                        new Setter(ListBox.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                        new Setter(ListBox.IsSynchronizedWithCurrentItemProperty, true)
                    }
                }
            });
            Control.StyleProperty.OverrideMetadata(typeof(ListBoxItem), new FrameworkPropertyMetadata() {
                DefaultValue = new Style() {
                    Setters = { new Setter(ListBoxItem.FocusVisualStyleProperty, null) }
                }
            });
        }
    }
}
