﻿using RentManager.CustomControls;
using SQLite.Abstracts;
using SQLite.CustomControls;
using SQLite.Helpers;
using SQLite.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace SQLite.Views
{
    class TableView : CardView
    {
        override public string Icon => Icons.TableSearch;
        public override string Header => "Table";
        Grid actionGrid;
        CommandButton refresh;
        TextBlock count;
        SelectItem selectTable;
        ResultGrid resultgrid;
        TableVM viewModel;

        public TableView() {
            viewModel = new TableVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void initializeUI() {
            count = new TextBlock() {
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5,0,5,0)
            };
            refresh = new CommandButton() {
                Icon = Icons.Refresh,
                ToolTip = "Refresh",
                Command = viewModel.Refresh
            };
            var actionPanel = new StackPanel() {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(0,0,0,7),
                Children = { count, refresh}
            };
            selectTable = new SelectItem() {
                DisplayPath = "Name",
                SelectedValuePath = "Name"
            };
            Grid.SetColumn(actionPanel, 1);
            actionGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(7, GridUnitType.Star )},
                    new ColumnDefinition(){ Width = new GridLength(1, GridUnitType.Star )}
                },
                Children = { selectTable, actionPanel }
            };
            setActionIcons(actionGrid);
            resultgrid = new ResultGrid();
            setContent(resultgrid);
        }

        void bind() {
            selectTable.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(viewModel.SelectedTable)));
            selectTable.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(viewModel.Tables)));
            selectTable.SetBinding(SelectItem.QueryProperty, new Binding(nameof(viewModel.Query)) { Mode = BindingMode.OneWayToSource });
            
            resultgrid.SetBinding(ResultGrid.ItemsSourceProperty, new Binding(nameof(viewModel.Data)));
            resultgrid.SetBinding(ResultGrid.QueryProperty, new Binding(nameof(viewModel.HeaderQuery)) { Mode = BindingMode.OneWayToSource });
            count.SetBinding(TextBlock.TextProperty, new Binding("Items.Count") { Source = resultgrid, StringFormat = "N0" });
            refresh.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.CanRefresh)));
        }
    }
}
