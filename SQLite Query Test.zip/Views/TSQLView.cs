﻿using SQLite.Abstracts;
using SQLite.Helpers;
using SQLite.Views.TSQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace SQLite.Views
{
    class TSQLView : View
    {
        override public string Icon => Icons.DatabaseSearch;
        public override FrameworkElement container => grid;
        Grid grid;
        public TSQLView() {
            var dbObjects = new DBObjects();
            var query = new Query();
            var message = new Message();
            var result = new Result();

            var splitter1 = new GridSplitter() { 
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Margin = new Thickness(0,7,0,7)
            };
            var splitter2 = new GridSplitter() { 
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Margin = new Thickness(0, 7, 0, 7)
            };
            var splitter3 = new GridSplitter() { 
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Margin = new Thickness(7, 0, 7, 0)
            };

            Grid.SetColumn(splitter1, 1);
            Grid.SetColumn(query, 2);
            Grid.SetColumn(message, 2);
            Grid.SetColumn(splitter2, 3);
            Grid.SetColumn(result, 4);
            Grid.SetColumn(splitter3, 2);

            Grid.SetRow(splitter3, 1);
            Grid.SetRow(message, 2);

            Grid.SetRowSpan(splitter1, 3);
            Grid.SetRowSpan(splitter2, 3);
            Grid.SetRowSpan(dbObjects, 3);
            Grid.SetRowSpan(result, 3);


            grid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){Height = new GridLength(7, GridUnitType.Star)},
                    new RowDefinition(){ Height = new GridLength(3)},
                    new RowDefinition()
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){Width = new GridLength(3)},
                    new ColumnDefinition(){Width = new GridLength(3, GridUnitType.Star)},
                    new ColumnDefinition(){Width = new GridLength(3)},
                    new ColumnDefinition(){Width = new GridLength(2, GridUnitType.Star)}
                },
                Children = {dbObjects, splitter1, query, splitter2, result, splitter3, message}
            };
            AddVisualChild(grid);
        }
    }
}
