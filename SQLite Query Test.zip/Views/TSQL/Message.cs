﻿using SQLite.Abstracts;
using SQLite.ControlTemplates;
using SQLite.CustomControls;
using SQLite.DataTemplates;
using SQLite.Helpers;
using SQLite.ItemsPanelTemplates;
using SQLite.Models;
using SQLite.ViewModels.TSQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace SQLite.Views.TSQL
{
    class Message : CardView
    {
        public override string Header => "Log";
        ActionButton clear;
        ItemsControl infos;
        MessageVM viewModel;
        public Message() {
            resetMargin(new Thickness(2, 2, 2, Constants.CardMargin.Bottom));
            viewModel = new MessageVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void initializeUI() {
            clear = new ActionButton() {
                Icon = Icons.Recycle,
                ToolTip = "Clear",
                Command = viewModel.ClearInfo,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            setActionIcons(clear);
            infos = new ItemsControl() {
                Template = new ScrollableItemsControlTemplate(),
                ItemTemplate = new ProcessingInfoTemplate(),
                ItemsPanel = new VirtualizingPanelTemplate(),
                HorizontalContentAlignment = HorizontalAlignment.Stretch
            };
            infos.SetValue(TextElement.ForegroundProperty, Brushes.Green);
            infos.SetValue(VirtualizingPanel.IsVirtualizingProperty, true);
            infos.SetValue(VirtualizingPanel.VirtualizationModeProperty, VirtualizationMode.Recycling);
            infos.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
            setContent(infos);
        }

        void bind() {
            infos.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(viewModel.Infos)));
        }
    }
}
