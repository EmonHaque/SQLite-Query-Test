﻿using SQLite.Abstracts;
using SQLite.CustomControls;
using SQLite.Helpers;
using SQLite.ViewModels.TSQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace SQLite.Views.TSQL
{
    class Query : CardView
    {
        public override string Header => "Query";
        RichQueryBox queryBox;
        StackPanel iconsPanel;
        CommandButton execute, comment, save;
        QueryVM viewModel;
        public Query() {
            resetMargin(new Thickness(2, Constants.CardMargin.Top, 2, 2));
            viewModel = new QueryVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }

        void initializeUI() {
            queryBox = new RichQueryBox();
            queryBox.Execute = viewModel.Execute;
            setContent(queryBox);

            execute = new CommandButton() {
                Icon = Icons.Execute,
                ToolTip = "Execute Query",
                Command = () => viewModel.Execute.Invoke(queryBox.Statements)
            };
            comment = new CommandButton() {
                Icon = Icons.Comment,
                ToolTip = "Comment/Uncomment\r\nSelected line(s)",
                Command = () => queryBox.Comment.Execute(null)
            };
            save = new CommandButton() {
                Icon = Icons.Save,
                ToolTip = "Save",
                Command = () => viewModel.Save.Invoke(queryBox.Statements)
            };
            iconsPanel = new StackPanel() {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Bottom,
                HorizontalAlignment = HorizontalAlignment.Right,
                Children = { execute, comment, save }
            };
            setActionIcons(iconsPanel);
        }

        void bind() {
            execute.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.CanExecute)));
            comment.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.CanExecute)));
            save.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.CanExecute)));
        }
    }
}
