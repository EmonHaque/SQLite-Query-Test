﻿using SQLite.Abstracts;
using SQLite.CustomControls;
using SQLite.Helpers;
using SQLite.ViewModels.TSQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace SQLite.Views.TSQL
{
    class Result : CardView
    {
        public override string Header => "Result";
        ResultGrid dGrid;
        TextBlock count;
        ResultVM viewModel;
        public Result() {
            resetMargin(new Thickness(2, Constants.CardMargin.Top, Constants.CardMargin.Right, Constants.CardMargin.Bottom));
            viewModel = new ResultVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            count = new TextBlock() {
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Bottom,
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray
            };
            setActionIcons(count);
            dGrid = new ResultGrid();
            setContent(dGrid);
        }
        void bind() {
            dGrid.SetBinding(ResultGrid.ItemsSourceProperty, new Binding(nameof(viewModel.Result)));
            dGrid.SetBinding(ResultGrid.QueryProperty, new Binding(nameof(viewModel.HeaderQuery)) { Mode = BindingMode.OneWayToSource });
            count.SetBinding(TextBlock.TextProperty, new Binding("Items.Count") { Source = dGrid, StringFormat = "N0" });
        }
    }
}
