﻿using SQLite.Abstracts;
using SQLite.ControlTemplates;
using SQLite.CustomControls;
using SQLite.DataTemplates;
using SQLite.Helpers;
using SQLite.ViewModels.TSQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace SQLite.Views.TSQL
{
    class DBObjects : CardView
    {
        public override string Header => "Objects";
        StackPanel iconsPanel;
        CommandButton addDatabase, refreshDatabase;
        ListBox databaseObjects;
        DBObjectsVM viewModel;

        public DBObjects() {
            resetMargin(new Thickness(Constants.CardMargin.Left, Constants.CardMargin.Top, 2, Constants.CardMargin.Bottom));
            viewModel = new DBObjectsVM();
            DataContext = viewModel;
            initializeUI();
            bind();
        }
        void initializeUI() {
            setActions();
            databaseObjects = new ListBox() {
                ItemTemplate = new DBObjectTemplate(),
                GroupStyle = {
                    new GroupStyle() {
                        ContainerStyle = new Style(typeof(GroupItem)) {
                            Setters = { new Setter(GroupItem.TemplateProperty, new GroupedDBObjectTemplate()) }
                        }
                    }
                },
            };
            setContent(databaseObjects);
        }

        void setActions() {
            addDatabase = new CommandButton() {
                Icon = Icons.DatabaseAdd,
                ToolTip = "Attach database",
                Command = viewModel.AttachDB
            };
            refreshDatabase = new CommandButton() {
                Icon = Icons.DatabaseRefresh,
                ToolTip = "Refresh database",
                Command = viewModel.RefreshDB
            };
            iconsPanel = new StackPanel() {
                Orientation = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Bottom,
                HorizontalAlignment = HorizontalAlignment.Right,
                Children = { addDatabase, refreshDatabase }
            };
            setActionIcons(iconsPanel);
        }

        void bind() {
            databaseObjects.SetBinding(ListBox.ItemsSourceProperty, new Binding($"{nameof(viewModel.DbObjects)}"));
            addDatabase.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.CanExecute)));
            refreshDatabase.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.CanExecute)));
        }
    }
}
