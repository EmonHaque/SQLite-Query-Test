﻿using Microsoft.Data.Sqlite;
using SQLite.Helpers;
using SQLite.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLite
{
    class AppData
    {
        public static string dbFileName;
        public static List<DBObjectInfo> dbObjects;
        public static List<FunKey> funKeys;
        public static SqliteConnection connection;

        public AppData() {
            getFunKeys();
            
        }

        void getFunKeys() {
            funKeys = new List<FunKey>();
            var files = Directory.GetFiles("KeysAndFunc", "*.txt");
            foreach (var file in files) {
                var name = file.Split("\\")[1].Replace(".txt", "");
                if (name.StartsWith("fn")) name = name.Remove(0, 2);
                var lines = File.ReadAllLines(file);
                string icon = "";
                switch (name) {
                    case "Scalar Function": icon = Icons.Equal; break;
                    case "Aggregate Function": icon = Icons.Sigma; break;
                    case "Math Function": icon = Icons.Integral; break;
                    case "Window Function": icon = Icons.Window; break;
                    case "Date And Time Function": icon = Icons.Timer; break;
                    case "JSON Function": icon = Icons.JavaScript; break;
                    case "Keyword": icon = Icons.Key; break;
                }
                foreach (var line in lines) {
                    funKeys.Add(new FunKey() {
                        Name = line,
                        Tag = name,
                        Icon = icon
                    });
                }
            }
        }
    }
}
