﻿using System.Windows;

namespace SQLite.Helpers
{
    class Constants
    {
        public const double ScrollBarThickness = 12;
        public static Thickness CardMargin = new Thickness(7);
    }
}
