﻿using System;
using System.Windows.Input;

namespace SQLite.Helpers
{
    public class Command : ICommand
    {
        Action<object> execute;
        Func<object, bool> canExecute;
        public Command(Action<object> execute, Func<object, bool> canExecute)
        {
            this.canExecute = canExecute;
            this.execute = execute;
            //CommandManager.RequerySuggested += (o, e) => OnCanExecuteChanged();
        }
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value;  }
        }
        //public void OnCanExecuteChanged() => CanExecuteChanged?.Invoke(null, EventArgs.Empty);
        public bool CanExecute(object parameter) => canExecute(parameter);
        public void Execute(object parameter) => execute(parameter);     
    }
}
