﻿using SQLite.CustomControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace SQLite.ControlTemplates
{
    class ExpanderTemplate : ControlTemplate
    {
        public ExpanderTemplate() {
            TargetType = typeof(Expander);
            var grid = new FrameworkElementFactory(typeof(Grid));
            var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
            var row1 = new FrameworkElementFactory(typeof(RowDefinition));
            var row2 = new FrameworkElementFactory(typeof(RowDefinition));

            var block = new FrameworkElementFactory(typeof(TextBlock));
            var button = new FrameworkElementFactory(typeof(BiState));
            var presenter = new FrameworkElementFactory(typeof(ContentPresenter)) { Name = "content"};

            col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
            button.SetValue(BiState.MarginProperty, new Thickness(0, 0, 5, 2));
            block.SetValue(Grid.ColumnProperty, 1);
            block.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
            
            presenter.SetValue(Grid.RowProperty, 1);
            presenter.SetValue(Grid.ColumnProperty, 1);
            presenter.SetValue(ContentPresenter.VisibilityProperty, Visibility.Collapsed);
            block.SetBinding(TextBlock.TextProperty, new Binding(nameof(Expander.Header)){
                RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent)
            });
            button.SetBinding(BiState.IsTrueProperty, new Binding(nameof(Expander.IsExpanded)) {
                RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent)
            });

            grid.AppendChild(row1);
            grid.AppendChild(row2);
            grid.AppendChild(col1);
            grid.AppendChild(col2);
            grid.AppendChild(block);
            grid.AppendChild(button);
            grid.AppendChild(presenter);

            VisualTree = grid;

            Triggers.Add(new Trigger() {
                Property = Expander.IsExpandedProperty,
                Value = true,
                Setters = { 
                    new Setter() { 
                        Property = Expander.VisibilityProperty, 
                        Value = Visibility.Visible,
                        TargetName = "content"
                    } 
                }
            });

        }
    }
}
