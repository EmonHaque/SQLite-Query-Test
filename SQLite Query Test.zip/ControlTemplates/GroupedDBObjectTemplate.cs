﻿using SQLite.CustomControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace SQLite.ControlTemplates
{
    class GroupedDBObjectTemplate : ControlTemplate
    {
        public GroupedDBObjectTemplate() {
            TargetType = typeof(GroupItem);
            var expander = new FrameworkElementFactory(typeof(Expander));
            var items = new FrameworkElementFactory(typeof(ItemsPresenter));
            expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
            expander.SetValue(Expander.IsExpandedProperty, true);
            expander.SetBinding(Expander.HeaderProperty, new Binding(nameof(GroupItem.Name)) { Mode = BindingMode.OneWay });
            expander.AppendChild(items);
            VisualTree = expander;
        }
    }
}
