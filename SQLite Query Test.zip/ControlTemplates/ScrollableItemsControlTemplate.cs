﻿using System.Windows;
using System.Windows.Controls;

namespace SQLite.ControlTemplates
{
    class ScrollableItemsControlTemplate : ControlTemplate
    {
        public ScrollableItemsControlTemplate() {
            TargetType = typeof(ItemsControl);
            var scrollViewer = new FrameworkElementFactory(typeof(ScrollViewer));
            var presenter = new FrameworkElementFactory(typeof(ItemsPresenter));
            scrollViewer.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
            scrollViewer.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
            scrollViewer.AppendChild(presenter);
            VisualTree = scrollViewer;
        }
    }
}
