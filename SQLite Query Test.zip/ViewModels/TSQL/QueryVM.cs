﻿using Microsoft.Data.Sqlite;
using Microsoft.Win32;
using SQLite.Abstracts;
using SQLite.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLite.ViewModels.TSQL
{
    class QueryVM : Notifiable
    {
        DataTable result;
        bool isExecuting;
        public bool IsExecuting {
            get { return isExecuting; }
            set { 
                isExecuting = value;
                CanExecute = !value;
                OnPropertyChanged(nameof(CanExecute));
            }
        }
        public bool CanExecute { get; set; }
        public Action<string> Execute { get; set; }
        public Action<string> Save { get; set; }
        public static event Action<DataTable> ResultSet;
        public static event Action<ProcessingInfo> QueryFinished;
        public QueryVM() {
            IsExecuting = false;
            Execute = execute;
            Save = save;
        }

        async void execute(string query) {
            if (IsExecuting) return;
            IsExecuting = true;
            await Task.Run(() => processQuery(query));
            IsExecuting = false;
        }
        void save(string content) {
            var dialog = new SaveFileDialog() {
                FileName = "statements",
                Filter = "SQL files (.sql)|*.sql"
            };
            if (dialog.ShowDialog() != true) return;
            File.WriteAllText(Path.GetFullPath(dialog.FileName), content);
        }
        void processQuery(string query) {
            var info = new ProcessingInfo();
            if (string.IsNullOrEmpty(AppData.dbFileName)) {
                info.IsError = true;
                info.Time = DateTime.Now.ToString("hh:mm:ss");
                info.Message = "No database attached!";
                QueryFinished?.Invoke(info);
                return;
            }
            info.IsError = false;
            var started = DateTime.Now;
            result = new DataTable();
            
            AppData.connection.Open();
            var command = AppData.connection.CreateCommand();
            command.CommandText = query;
            try { result.Load(command.ExecuteReader(CommandBehavior.CloseConnection)); }
            catch (Exception e) {
                info.Time = DateTime.Now.ToString("hh:mm:ss");
                info.IsError = true;
                info.Message = e.Message;
            }
            if (info.IsError) {
                QueryFinished?.Invoke(info);
                return;
            }
            var finished = DateTime.Now;
            var elapsed = finished - started;
            info.Time = DateTime.Now.ToString("hh:mm:ss");
            info.Message = $"Execution finished in {elapsed.TotalMilliseconds.ToString("N0")} ms. Returned {result.Rows.Count.ToString("N0")} row(s)";
            ResultSet?.Invoke(result);
            QueryFinished?.Invoke(info);
        }
    }
}
