﻿using SQLite.Abstracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLite.ViewModels.TSQL
{
    class ResultVM : Notifiable
    {
        public DataView Result { get; set; }
        string headerQuery;
        public string HeaderQuery {
            get { return headerQuery; }
            set { 
                headerQuery = value;
                try { Result.RowFilter = value; }
                catch { }
            }
        }

        public ResultVM() {
            Result = new DataView();
            QueryVM.ResultSet += onResultSet;
        }

        private void onResultSet(DataTable table) {
            Result = table.DefaultView;
            OnPropertyChanged(nameof(Result));
        }
    }
}
