﻿using Microsoft.Data.Sqlite;
using Microsoft.Win32;
using SQLite.Abstracts;
using SQLite.Helpers;
using SQLite.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Data;

namespace SQLite.ViewModels.TSQL
{
    class DBObjectsVM : Notifiable
    {
        bool canExecute;
        public bool CanExecute {
            get { return canExecute; }
            set { canExecute = value; OnPropertyChanged(nameof(CanExecute)); }
        }

        public Action AttachDB { get; set; }
        public Action RefreshDB { get; set; }
        public ICollectionView DbObjects { get; set; }
        public static event Action<ProcessingInfo> Connected;
        public DBObjectsVM() {
            AttachDB = attachDB;
            RefreshDB = refreshDB;
            CanExecute = true;
        }

        async void attachDB() {
            var dialog = new OpenFileDialog();
            if (!dialog.ShowDialog().Value) return;

            CanExecute = false;
            AppData.dbFileName = dialog.FileName;
            AppData.connection = new SqliteConnection("data source = " + AppData.dbFileName);
            await Task.Run(resetObjects);
            CanExecute = true;
        }
        async void refreshDB() {
            CanExecute = false;
            await Task.Run(resetObjects);
            CanExecute = true;
        }

        void getObjects() {
            var info = new ProcessingInfo() { IsError = false };
            AppData.dbObjects = new List<DBObjectInfo>();
            AppData.connection.Open();
            var command = AppData.connection.CreateCommand();
            command.CommandText = "SELECT * FROM sqlite_master";
            SqliteDataReader reader = null;
            try { reader = command.ExecuteReader(); }
            catch(Exception e) {
                AppData.connection.Close();
                info.Time = DateTime.Now.ToString("hh:mm:ss");
                info.IsError = true;
                info.Message = e.Message;
                Connected?.Invoke(info);
                return;
            }

            while (reader.Read()) {
                AppData.dbObjects.Add(new DBObjectInfo() {
                    Type = reader.GetString(0).ToUpper(),
                    Name = reader.GetString(1)
                });
            }
            reader.Close();

            var txt = "";
            int count = 0;
            foreach (var dbobject in AppData.dbObjects) {
                if (dbobject.Type.Equals("TABLE")) {
                    txt += $"PRAGMA table_info({dbobject.Name});";
                    count++;
                    AppData.funKeys.Add(new FunKey() {
                        Name = dbobject.Name,
                        Tag = "Table",
                        Icon = Icons.Table
                    });
                }
                else if (dbobject.Type.Equals("VIEW")) {
                    txt += $"PRAGMA table_info({dbobject.Name});";
                    count++;
                    AppData.funKeys.Add(new FunKey() {
                        Name = dbobject.Name,
                        Tag = "View",
                        Icon = Icons.View
                    });
                }
                else if (dbobject.Type.Equals("INDEX")) {
                    AppData.funKeys.Add(new FunKey() {
                        Name = dbobject.Name,
                        Tag = "Index",
                        Icon = Icons.Index
                    });
                }
                else if (dbobject.Type.Equals("TRIGGER")) {
                    AppData.funKeys.Add(new FunKey() {
                        Name = dbobject.Name,
                        Tag = "Trigger",
                        Icon = Icons.Trigger
                    });
                }
            }
            command.CommandText = txt;
            reader = command.ExecuteReader();
            List<string> columnNames = new();
            for (int i = 0; i < count; i++) {
                while (reader.Read()) {
                    var str = reader.GetString(1);
                    if (columnNames.Contains(str)) continue;
                    columnNames.Add(str);

                    AppData.funKeys.Add(new FunKey() {
                        Name = str,
                        Tag = "Column",
                        Icon = Icons.Column
                    });
                }
                reader.NextResult();
            }

            AppData.connection.Close();
            DbObjects = new CollectionViewSource() { Source = AppData.dbObjects }.View;
            DbObjects.GroupDescriptions.Add(new PropertyGroupDescription("Type"));
            OnPropertyChanged(nameof(DbObjects));

            info.Time = DateTime.Now.ToString("hh:mm:ss");
            info.Message = "Conntected to database\r\n" + AppData.dbFileName;
            Connected?.Invoke(info);
        }

        void resetObjects() {
            var remove = AppData.funKeys
                .Where(x => 
                x.Tag.Equals("Table") || 
                x.Tag.Equals("Column") || 
                x.Tag.Equals("Index") || 
                x.Tag.Equals("Trigger") || 
                x.Tag.Equals("View"))
                .ToList();
            foreach (var r in remove) AppData.funKeys.Remove(r);        
            getObjects();
        }
    }
}
