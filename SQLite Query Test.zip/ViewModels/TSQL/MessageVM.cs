﻿using SQLite.Abstracts;
using SQLite.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace SQLite.ViewModels.TSQL
{
    class MessageVM : Notifiable
    {
        public ObservableCollection<ProcessingInfo> Infos { get; set; }
        public Action ClearInfo { get; set; }
        public MessageVM() {
            Infos = new ObservableCollection<ProcessingInfo>();
            ClearInfo = clearInfo;
            QueryVM.QueryFinished += onProcessFinished;
            DBObjectsVM.Connected += onProcessFinished;
        }
        void onProcessFinished(ProcessingInfo info) {
            App.Current.Dispatcher.Invoke(() => Infos.Insert(0, info));
        }
        void clearInfo() {
            App.Current.Dispatcher.Invoke(() => Infos.Clear());
        }
    }
}
