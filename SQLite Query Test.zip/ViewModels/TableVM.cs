﻿using Microsoft.Data.Sqlite;
using SQLite.Abstracts;
using SQLite.Models;
using SQLite.ViewModels.TSQL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace SQLite.ViewModels
{
    class TableVM : Notifiable
    {
        string query;
        public string Query {
            get { return query; }
            set { query = value?.ToLower(); Tables?.Refresh(); }
        }
        string headerQuery;
        public string HeaderQuery {
            get { return headerQuery; }
            set { headerQuery = value; filterRow(); }
        }
        string selectedTable;
        public string SelectedTable {
            get { return selectedTable; }
            set { selectedTable = value; if (value != null) execute(); }
        }
        bool canRefresh;
        public bool CanRefresh {
            get { return canRefresh; }
            set { canRefresh = value; OnPropertyChanged(nameof(CanRefresh)); }
        }

        public ICollectionView Tables { get; set; }
        public Action Refresh { get; set; }
        public DataView Data { get; set; }
        public static event Action IsRefreshing;

        public TableVM() {
            Refresh = refresh;
            DBObjectsVM.Connected += onConnected;
            if (AppData.dbObjects is not null) onConnected(null);
        }
        void onConnected(ProcessingInfo info) {
            Tables = new CollectionViewSource() { Source = AppData.dbObjects }.View;
            Tables.Filter = filter;
            OnPropertyChanged(nameof(Tables));
        }

        bool filter(object o) {
            var obj = (DBObjectInfo)o;
            return string.IsNullOrWhiteSpace(Query) ?
                obj.Type.Equals("TABLE") :
                obj.Type.Equals("TABLE") && obj.Name.ToLower().Contains(Query);
        }

        void filterRow() {
            CanRefresh = false;

            if (Data is null) return;
            try { Data.RowFilter = HeaderQuery; }
            catch { }

            CanRefresh = true;
        }

        void refresh() {
            IsRefreshing?.Invoke();
            execute();
        }

        async void execute() {
            CanRefresh = false;
            await Task.Run(resetData);
            CanRefresh = true;
        }

        void resetData() {
            var data = new DataTable();
            var con = new SqliteConnection("data source = " + AppData.dbFileName);
            con.Open();
            var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM " + SelectedTable;
            data.Load(cmd.ExecuteReader(CommandBehavior.CloseConnection));

            Data = data.DefaultView;
            OnPropertyChanged(nameof(Data));
        }
    }
}
