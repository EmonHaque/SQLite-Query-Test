﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace SQLite.ItemsPanelTemplates
{
    class VirtualizingPanelTemplate : ItemsPanelTemplate
    {
        public VirtualizingPanelTemplate() {
            var panel = new FrameworkElementFactory(typeof(VirtualizingStackPanel));
            VisualTree = panel;
        }
    }
}
